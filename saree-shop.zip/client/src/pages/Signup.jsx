import React from 'react';
const Signup = () => <p>Signup form goes here</p>;
export default Signup;
