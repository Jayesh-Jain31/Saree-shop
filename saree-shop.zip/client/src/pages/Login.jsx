import React from 'react';
const Login = () => <p>Login form goes here</p>;
export default Login;
